import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-admins',
  templateUrl: './manage-admins.component.html',
  styleUrls: ['./manage-admins.component.css']
})
export class ManageAdminsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
