export class CustomerInformation {
    customerId:number;
    emailAddress:string;
    fullName:string;
    password:string;
    phoneNumber:number;
    city:string;
    zipCode:number;
    country:string;
    regsiterDate:string;
}
