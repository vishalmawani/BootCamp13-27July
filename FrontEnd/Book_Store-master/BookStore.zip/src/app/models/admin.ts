export class Admin {
    email:string;
    password:string;
    fullname:string;
}
