import { CustomerInformation } from './customer-information';

describe('CustomerInformation', () => {
  it('should create an instance', () => {
    expect(new CustomerInformation()).toBeTruthy();
  });
});
