import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-customers',
  templateUrl: './manage-customers.component.html',
  styleUrls: ['./manage-customers.component.css']
})
export class ManageCustomersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
